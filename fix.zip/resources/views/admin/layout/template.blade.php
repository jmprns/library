@extends('admin.layout.app')

{{-- HTML Title --}}
@section('html-title')

@endsection


{{-- Css --}}
@section('css')

@endsection

{{-- Page Title --}}
@section('page-title')

@endsection

{{-- Page Title Sub --}}
@section('page-title-sub')

@endsection


{{-- Main Content --}}
@section('main-content')

@endsection


{{-- Js Script --}}
@section('js')

@endsection