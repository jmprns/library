<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RealSub extends Model
{
    protected $fillable = ['name'];
}
